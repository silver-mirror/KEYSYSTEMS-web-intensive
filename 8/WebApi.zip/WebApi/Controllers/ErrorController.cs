﻿using System.Web.Mvc;

namespace WebApplication2.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class ErrorController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        public ActionResult Index()
        {
            HttpContext.Response.StatusCode = 555;
            return Json("Server error", JsonRequestBehavior.AllowGet);
        }
    }
}
