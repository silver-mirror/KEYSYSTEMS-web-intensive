﻿using System;
using System.Web.Mvc;

namespace WebApplication2.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class PostController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        public class PostResult
        {
            /// <summary>
            /// 
            /// </summary>
            public int Value { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public bool Ok { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        [HttpPost]
        public ActionResult Index(int value)
        {
            return Json(new PostResult
            {
                Value = value + 1,
                Ok = true
            });
        }
    }
}
