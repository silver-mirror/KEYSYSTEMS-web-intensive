﻿using System;
using System.Web.Mvc;

namespace WebApplication2.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class GetController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        public class GetResult
        {
            /// <summary>
            /// 
            /// </summary>
            public string Data { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public bool Ok { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        public ActionResult Index()
        {
            //return Json(new GetResult
            //{
            //    Data = "Some data",
            //    Ok = true
            //}, JsonRequestBehavior.AllowGet);
            return Json("{\"Data\": \"Some stringified data\"}", JsonRequestBehavior.AllowGet);
        }
    }
}