﻿using System.Threading;
using System.Web.Mvc;

namespace WebApplication2.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class GetLongController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        public class GetResult
        {
            /// <summary>
            /// 
            /// </summary>
            public string Data { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public bool Ok { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        public ActionResult Index()
        {
            Thread.Sleep(10000);

            return Json(new GetResult
            {
                Data = "Some long-read data",
                Ok = true
            }, JsonRequestBehavior.AllowGet);
        }
    }
}
