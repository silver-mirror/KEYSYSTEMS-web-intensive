﻿using System.Web.Mvc;

namespace WebApplication2.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class GetCorsController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        public class GetResult
        {
            /// <summary>
            /// 
            /// </summary>
            public string Data { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public bool Ok { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        public ActionResult Index()
        {
            HttpContext.Response.Headers["Access-Control-Allow-Origin"] = "*";

            return Json(new GetResult
            {
                Data = "Some data from another domain",
                Ok = true
            }, JsonRequestBehavior.AllowGet);
        }
    }
}
