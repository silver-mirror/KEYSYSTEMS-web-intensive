﻿// GET
function getSample() {
    $.ajax({
        url: 'http://localhost/webapi/Get',
        type: 'GET',
        success: function (result) {
            result = JSON.parse(result);
            console.log(result.Data);
        }
    });
}






// GET ERROR
function getErrorSample() {
    $.ajax({
        url: 'http://localhost/webapi/Error',
        type: 'GET',
        success: function(result) {
            console.log(result.Data);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(jqXHR, textStatus, errorThrown);
        }
    });
}






// POST
postData = {
    value: 10
}
function postSample() {
    $.ajax({
        url: 'http://localhost/webapi/Post',
        data: postData,
        dataType: 'json',
        type: 'POST',
        success: function (result) {
            postData.value = result.Value;
            console.log("value = " + postData.value);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR, textStatus, errorThrown);
        }
    });
}








// GET SYNC
function getSyncSample() {
    $.ajax({
        url: 'http://localhost/webapi/GetLong',
        type: 'GET',
        async: false,
        success: function (result) {
            console.log(result.Data);
        }
    });
}







// CORS
function getCorsSample() {
    $.ajax({
        url: 'http://ks-487/webapi/GetCors',
        type: 'GET',
        success: function (result) {
            console.log(result.Data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR, textStatus, errorThrown);
        }
    });
}
